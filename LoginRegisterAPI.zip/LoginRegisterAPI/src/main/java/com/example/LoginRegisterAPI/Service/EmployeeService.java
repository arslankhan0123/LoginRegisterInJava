package com.example.LoginRegisterAPI.Service;

import com.example.LoginRegisterAPI.Dto.EmployeeDTO;

public interface EmployeeService {
    String addEmployee(EmployeeDTO employeeDTO);
}
