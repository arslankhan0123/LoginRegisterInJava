package com.example.LoginRegisterAPI.EmployeeController;
import com.example.LoginRegisterAPI.Dto.EmployeeDTO;
//import com.example.LoginRegisterAPI.Dto.LoginDTO;
import com.example.LoginRegisterAPI.Service.EmployeeService;
//import com.example.LoginRegisterAPI.response.LoginResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@CrossOrigin
@RequestMapping("api/v1/employee")
public class EmployeeController {
//    @Autowired
    private EmployeeService employeeService;
    @PostMapping(path = "/save")
    public String saveEmployee(@RequestBody EmployeeDTO employeeDTO)
    {
        System.out.println("employeeDTO: " + employeeDTO);
        String id = employeeService.addEmployee(employeeDTO);
        return id;
    }
}